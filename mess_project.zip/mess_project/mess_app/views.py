from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.utils.timezone import localtime, now
from datetime import datetime, timedelta
from django.contrib import messages
from django.contrib.auth.hashers import make_password

from .models import User, FoodSelection
from .forms import StudentSignupForm


def home(request):
    return render(request, 'home.html')


# ✅ Student Registration
def student_signup(request):
    if request.method == 'POST':
        form = StudentSignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'student'
            user.password = make_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, 'Signup successful! Please log in.')
            return redirect('student_login')
    else:
        form = StudentSignupForm()
    return render(request, 'student_signup.html', {'form': form})


# ✅ Student Login
def student_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user and user.role == 'student':
            login(request, user)
            return redirect('student_dashboard')
        messages.error(request, 'Invalid credentials or not registered as a student.')
    return render(request, 'student_login.html')


# ✅ Cook Login
def cook_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user and user.role == 'cook':
            login(request, user)
            return redirect('cook_dashboard')
        messages.error(request, 'Invalid credentials or not registered as a cook.')
    return render(request, 'cook_login.html')


# ✅ Student Dashboard
@login_required
def student_dashboard(request):
    user = request.user
    current_time = localtime(now())
    can_submit = 10 <= current_time.hour <= 17

    if request.method == 'POST' and can_submit:
        selected_date_str = request.POST.get('date')
        if selected_date_str:
            selected_date = datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            want_food = request.POST.get('want_food') == 'yes'

            if selected_date <= current_time.date():
                messages.error(request, "Cannot select today or past dates.")
            elif FoodSelection.objects.filter(user=user, date=selected_date).exists():
                messages.error(request, "You already submitted your choice for this date.")
            else:
                FoodSelection.objects.create(user=user, date=selected_date, want_food=want_food)
                messages.success(request, "Your response has been recorded.")
                return redirect('student_dashboard')
        else:
            messages.error(request, "Invalid date selected.")

    return render(request, 'student_dashboard.html', {'can_submit': can_submit})


# ✅ Cook Dashboard
@login_required
def cook_dashboard(request):
    tomorrow = now().date() + timedelta(days=1)
    selections = FoodSelection.objects.filter(date=tomorrow, want_food=True)
    count = selections.count()
    return render(request, 'cook_dashboard.html', {
        'selections': selections,
        'count': count
    })
