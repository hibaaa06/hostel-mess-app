from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, FoodSelection

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ['username', 'role', 'semester', 'department']
    fieldsets = UserAdmin.fieldsets + (
        ('Extra Info', {'fields': ('role', 'semester', 'department')}),
    )

admin.site.register(User, CustomUserAdmin)
admin.site.register(FoodSelection)
