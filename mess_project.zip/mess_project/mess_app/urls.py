from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('student/login/', views.student_login, name='student_login'),
    path('cook/login/', views.cook_login, name='cook_login'),
    path('student/register/', views.student_signup, name='student_register'),  # this fixes the error
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('cook/dashboard/', views.cook_dashboard, name='cook_dashboard'),
]
